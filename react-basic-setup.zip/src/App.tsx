import React from 'react';
import './App.css';

function App() {
  return (
    <div >
      Hello React with ts
    </div>
  );
}

export default App;
